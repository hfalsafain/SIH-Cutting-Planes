#include <vector>
#include <set>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <map>

using namespace std;

struct line
{
	int id, start, end;
	set<int> nongap;
	string str;
};

vector<line> lines;

void main(int argc, char* argv[])
{

	//Reading the input file
	{
		cout << "Reading . . ." << endl;
		ifstream ifs(argv[1]);
		string ifline;
		while (getline(ifs, ifline))
		{
			if (ifline.length() == 0)
				continue;
			int lineid;
			stringstream ss(ifline);
			string subss;
			int entry = 1;
			int last;
			line currentline;
			currentline.str = ifline;
			while (ss >> subss)
			{
				if (entry == 1)
				{
					lineid = stoi(subss);
					currentline.id = lineid;
				}
				else if (entry % 2 == 0)
				{
					last = stoi(subss);
				}
				else
				{
					for (int cc = 0; cc < subss.length(); cc++)
					{
						currentline.nongap.insert(last + cc);
					}
				}
				entry++;
			}
			currentline.start = *currentline.nongap.begin();
			currentline.end = *currentline.nongap.rbegin();
			lines.push_back(currentline);
		}
	}

	cout << "# Lines = " << lines.size() << endl;
	int blk = 1;
	int MaxBlockSize = 0, MaxLength = 0, MaxCov = 0;
	map<int, int> coverages;
	while (!lines.empty())
	{
		line currentline = *lines.begin();
		lines.erase(lines.begin());
		vector<line> block;
		block.push_back(currentline);
		for (auto cov : currentline.nongap)
		{
			coverages[cov]+= 1;
		}
		auto it = lines.begin();
		while (!lines.empty() && it != lines.end())
		{
			if ((*it).start > currentline.end)
			{
				break;
			}
			vector<int> intersectvec, univec;
			set_intersection(currentline.nongap.begin(), currentline.nongap.end(), (*it).nongap.begin(), (*it).nongap.end(), back_inserter(intersectvec));
			set_union(currentline.nongap.begin(), currentline.nongap.end(), (*it).nongap.begin(), (*it).nongap.end(), back_inserter(univec));
			if (intersectvec.empty())
			{
				it++;
			}
			else
			{
				block.push_back((*it));
				for (auto cov : (*it).nongap)
				{
					coverages[cov] += 1;
				}
				set<int> uniset(univec.begin(), univec.end());
				currentline.nongap = uniset;
				currentline.start = *uniset.begin();
				currentline.end = *uniset.rbegin();
				lines.erase(it);
				it = lines.begin();
			}
		}
		//
		int blklength = *currentline.nongap.rbegin() - *currentline.nongap.begin() + 1;//currentline.nongap.size();
		string blkfilename = argv[1];
		blkfilename += "_block";
		blkfilename += to_string(blk).c_str();
		blk++;
		ofstream ofs(blkfilename);
		for (auto b : block)
		{
			ofs << b.str << endl;
		}
		int blkmaxcov = 0;
		for (auto cov : coverages)
		{
			blkmaxcov = max(blkmaxcov, cov.second);
		}
		cout << "Block " << blk - 1 << " is written. #Lines = " << block.size() <<  " Length = " << blklength << " Max. Coverage = " << blkmaxcov <<  " #Remaining Lines = " << lines.size() << endl;
		MaxBlockSize = max(MaxBlockSize, (int)block.size());
		MaxLength = max(MaxLength, blklength);
		MaxCov = max(MaxCov, blkmaxcov);
		coverages.clear();
		ofs.close();
	}
	cout << "==========" << endl;
	cout << "Maximum number of reads in a block = " << MaxBlockSize << endl;
	cout << "Maximum length of a block = " << MaxLength << endl;
	cout << "Maximum coverage of a block = " << MaxCov << endl;
	cout << "==========" << endl;
}